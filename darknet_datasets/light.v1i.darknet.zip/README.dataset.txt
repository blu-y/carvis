# light > 2022-09-24 2:37pm
https://universe.roboflow.com/object-detection/light-rn2ps

Provided by Roboflow
License: CC BY 4.0

