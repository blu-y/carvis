# secondtry > 2022-09-24 7:03am
https://universe.roboflow.com/object-detection/secondtry

Provided by Roboflow
License: CC BY 4.0

